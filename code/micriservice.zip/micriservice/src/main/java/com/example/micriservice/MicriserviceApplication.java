package com.example.micriservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MicriserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(MicriserviceApplication.class, args);
	}

}
